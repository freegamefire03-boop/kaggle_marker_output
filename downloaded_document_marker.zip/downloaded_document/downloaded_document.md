# THE ART OF CONVERSATION TWELVE GOLDEN RULES

![](_page_0_Picture_1.jpeg)

#### BY

#### JOSEPHINE TURCK BAKER

AUTHOR OF

CORRECT ENGLISH: A COMPLETE GRAMMAR
TEN THOUSAND WORDS: HOW TO PRONOUNCE THEM

AND EDITOR OF THE MAGAZINE

CORRECT ENGLISH: HOW TO USE IT

# PUBLISHED BY CORRECT ENGLISH PUBLISHING COMPANY EVANSTON, ILLINOIS

# THE ART OF CONVERSATION TWELVE GOLDEN RULES

![](_page_1_Picture_1.jpeg)

#### BY

#### JOSEPHINE TURCK BAKER

AUTHOR OF

CORRECT ENGLISH: A COMPLETE GRAMMAR
TEN THOUSAND WORDS: HOW TO PRONOUNCE THEM

AND EDITOR OF THE MAGAZINE

CORRECT ENGLISH: HOW TO USE IT

PUBLISHED BY

CORRECT ENGLISH PUBLISHING COMPANY

EVANSTON, ILLINOIS

#### **The Project Gutenberg eBook of The Art of Conversation: Twelve Golden Rules**

This ebook is for the use of anyone anywhere in the United States and most other parts of the world at no cost and with almost no restrictions whatsoever. You may copy it, give it away or re-use it under the terms of the Project Gutenberg License included with this ebook or online at [www.gutenberg.org.](https://www.gutenberg.org) If you are not located in the United States, you will have to check the laws of the country where you are located before using this eBook.

Title: The Art of Conversation: Twelve Golden Rules

Author: Josephine Turck Baker

Release date: December 9, 2020 [eBook #63995]

Language: English

\*\*\* START OF THE PROJECT GUTENBERG EBOOK THE ART OF CONVERSATION: TWELVE GOLDEN RULES \*\*\*

**E-text prepared by Turgut Dincer, Martin Pettit, and the Online Distributed Proofreading Team (https://www.pgdp.net) from page images generously made available by Internet Archive (https://archive.org)**

Note: Images of the original pages are available through Internet Archive. See https://archive.org/details/artofconversatio01bake

![](_page_4_Picture_0.jpeg)

#### BY

#### JOSEPHINE TURCK BAKER

AUTHOR OF

CORRECT ENGLISH: A COMPLETE GRAMMAR TEN THOUSAND WORDS: HOW TO PRONOUNCE THEM

> AND EDITOR OF THE MAGAZINE CORRECT ENGLISH: HOW TO USE IT

PUBLISHED BY
CORRECT ENGLISH PUBLISHING COMPANY
EVANSTON, ILLINOIS

THE ART OF

# **CONVERSATION TWELVE GOLDEN RULES**

![](_page_5_Picture_1.jpeg)

#### **BY**

# **JOSEPHINE TURCK BAKER**

**AUTHOR OF CORRECT ENGLISH: A COMPLETE GRAMMAR TEN THOUSAND WORDS: HOW TO PRONOUNCE THEM AND EDITOR OF THE MAGAZINE CORRECT ENGLISH: HOW TO USE IT**

**PUBLISHED BY CORRECT ENGLISH PUBLISHING COMPANY EVANSTON, ILLINOIS**

> COPYRIGHT, 1907 BY JOSEPHINE TURCK BAKER

# **THE ART OF CONVERSATION**

#### **TWELVE GOLDEN RULES**

# **GOLDEN RULE NUMBER I**

*Avoid unnecessary details.*

He.—Do you know that what you say always interests me?

She.—That is because we are such good comrades.

He.—Not altogether. I think that it is because you never dwell upon details.

She.—Then, one is interesting in conversation according as one omits details?

He.—Unnecessary details.

She.—I remember that, when visiting some friends whom I had not seen for several years, my hostess said to me, "Ever since your arrival, I have been trying to discover why you are so interesting in conversation, and I have decided that it is because you omit unnecessary details." I felt that my hostess had paid me a high compliment.

He.—Yes; but one that you deserve. Now, even in telling this incident, you were direct. The bore would have "side-tracked," and would have told innumerable and irrelevant details. I don't believe you could bore a person if you were to try.

She.—I am quite sure that I could. Listen to this: "Several years ago,—four years ago just,—this last June; no, it was only three years ago, because I remember now that four years ago I did not attend the alumnae reunion of our college, and so it must have been three years ago,—I was the guest of one of the members of my class,—I was attending the annual reunion of the alumnae of our college,—almost every year I attend the alumnae reunion of our college,—and on this occasion, I was the guest of one of the members of my class. She had not been attending the reunions, and so I had not seen her for several years,—five years at least, and——"

He.—Pardon my interruption, but you are a success.

She.—As a bore?

He.—No; as an imitator. I think that you should have been an actress.

She.—Yes; I think that Nature intended me for one; and I could have "acted." Indeed, I usually find it difficult not to act; that is, I find it difficult to be myself.

He.—Like "Sensational Tommy" in "Tommy and Grizel"?

She.—Yes; in a way.

He.—And why were you not an actress? Was it because you did not know that you had talent?

She.—From an opposite reason. I had so many talents that, like the woman in "Mother Goose," I hardly knew what to do.

He.—That sounds modest. You probably would have been a great actress.

She.—I might not have been. Sometimes, you know, persons who are very gifted seem to miss the best that life has to offer.

He.—I have decided that you are interesting, not because you do not "sidetrack," but because you have such a stupendous amount of conceit. You seem to be fully aware of what you possess. It is delightful.

She.—My talent or my conceit?

He.—Both.

She.—I am sure that if any one else possessed my talents, I should not hesitate to speak of them. Why should I not speak of mine?

He.—That is one way to look at it. Now, I suppose if I were to tell you that you were very gifted, you would say, "Thank you; I think that I am, too,"—or words to that effect.

She.—Yes; I think that I should respond in some such way. Why should I not? Why shouldn't I recognize my gifts and be thankful for them?

He.—Well, usually, you know, when any one receives a compliment, he is

apt to regard it as flattery, and to treat it accordingly; or, if he thinks the praise is merited, his words are apt to belie his thoughts.

She.—Yes, but that brooks of insincerity. However, we are a long way from our subject. We were wondering why some persons "bore" and why some do not. We decided that one must under no circumstances enter into too many details.

He.—They are ruinous. If a person is very polite, he will feign an interest that he does not feel. Often, however, he betrays, by an absent expression, that the "details" have done their "deadly work." You always seem interested, I notice, even when the narrator has wandered from the main road into innumerable by-paths.

She.—I appear interested, because I am interested, for I am continually on the alert to find out just how he is going to get back to the main road. I find, however, that in the majority of cases, he never gets back. He is lost in such a labyrinth that, as compared with it, the Garden of Versailles and the "maze" of Hampton Court are as naught; and just as these world-famed networks have a kind of attraction for the curious, so I find it interesting to follow the bore as he goes from one intricate passage into another in his endeavor to find an exit. But I must leave him to his fate, or I, too, shall be lost in a "maze" and shall not be able to find the main path.

He.—Then, Golden Rule Number I is: AVOID UNNECESSARY DETAILS. I shall try to remember the rule, and profit by its significance.

# **GOLDEN RULE NUMBER II**

*Do not ask question number two until number one has been answered.*

He.—Since our last visit, I have been noticing the faults of my friends in conversation, and I have concluded that the most glaring fault one can have is to ask questions and then not wait for the answers. I have one friend in particular who, whenever he meets me asks in the most solicitous way about my family, my health, etc., and then before I have an opportunity to respond, he proceeds to tell me about himself, his family, his ills, and the like.

She.—I know the species very well. In fact, I have classified my friends according to their respective merits as listeners.

He.—And where have you placed me?

She.—At the head of the list.

He.—As the greatest offender?

She.—No; as the least. You always wait until I answer one question before you ask another.

He.—Thank you. Do I ask many questions?

She.—Not too many. You may have noticed that there are as many persons who ask too few questions as there are who ask too many.

He.—I must say that I had never thought of that.

She.—To ask many questions often indicates an undue amount of curiosity on the part of the questioner; to ask too few, a lack of interest. The reason why some persons are so very prosaic and uninteresting is that they are entirely absorbed in themselves; in consequence, they ask few or no questions whatever, showing that they are not in the least concerned in what interests their friends. There is a happy mean where one shows neither curiosity nor disinterest.

He.—In asking questions, we are apt to stir up a hornet's nest, so to speak, for our friends sometimes respond at such length that we are inclined to wish that we had shown less interest.

She.—That is where it is so necessary to remember the golden rule that we spoke of in our last conversation, namely, AVOID UNNECESSARY DETAILS.

He.—Yes; and as I have already told you, that is why you are always interesting; you never bore one with a "long story."

She.—I usually try to treat all my friends as carefully as if each one bore a tag marked, "THIS IS MY BUSY DAY; MAKE IT SHORT."

He.—Yes; or, "I<sup>F</sup> YOU HAVE ANY TIME TO KILL, KILL YOUR OWN." At what a rapid pace we live, anyway. People in the country—the peasant class—are never in a hurry. They talk slowly, eat slowly, and work at the same laggard pace.

She.—In other words, they exist, but do not live. They do not enjoy what we enjoy. A daily feast is spread before them, but they do not partake of it. What do they know of glowing sunsets and of moonlit waves; of shaded walks through pathless woods; of narrow streams in-walled with trees? The sunset tells the peasant only of what the weather will bring to his crops; the stretch of velvet through which the streamlet winds, of green pastures for his flocks. But I have gotten away from my subject. In other words, like the bore, I have "side-tracked."

He.—Only what you say does not bore.

She.—You mean, not you.

He.—Nor any one else.

She.—Thank you.

He.—I should thank you, instead. Now, I am to remember, first, that Golden Rule Number I is.: AVOID UNNECESSARY DETAILS. Rule Number II.: D<sup>O</sup> NOT ASK QUESTION NUMBER TWO UNTIL QUESTION NUMBER ONE HAS BEEN ANSWERED; and, furthermore, one must be neither too curious nor too disinterested; that is, one must not ask too few nor too many questions; just enough. I fear that I shall find it difficult to observe this rule, but I shall try to acquire the tact that is necessary for one to have. May I practice the art when with you?

| She.—That<br>will<br>be | charming,<br>and<br>you<br>may<br>begin<br>at<br>once. |  |
|-------------------------|--------------------------------------------------------|--|
|                         |                                                        |  |
|                         |                                                        |  |
|                         |                                                        |  |
|                         |                                                        |  |

# **GOLDEN RULE NUMBER III**

*Do not interrupt another while he is speaking.*

He.—So we agree that the greatest fault that a person can have is to ask questions, and then, without waiting for the answers, to plunge at once into a detailed account of his own doings. I have discovered another fault, and one, I fear, that I, too, possess; that is, to ask questions concerning the welfare of my friend and of his family, and then after he has gotten fairly under way in the recital of his woes, to interrupt him with irrelevant remarks.

She.—I am sure that you haven't this fault, although it is very common. It is based upon the principle that people, as a rule, are vitally concerned only in what concerns themselves. I have a friend who maintains that no one really enjoys listening to what another has to say. He says that the interested (?) listener is interested only in having the other person finish in order that he may have the opportunity to tell his story.

He.—I note, however, that, as a rule, people recite their woes, and not their "weals." But, of course, that depends upon the individual. Some persons always have a "hard luck story;" others, dwell upon the bright happenings in their lives.

She.—I think we each can recall some friend whose greatest pleasure is to pose as a martyr; another, who, no matter what are his ills, has always something of interest to impart pertaining to some good fortune, fancied or otherwise, which has befallen him.

He.—Speaking of our faults, I think that the best way to correct them is to notice them in our friends, and then to try to avoid them. But, of course, you haven't any.

She.—Any friends?

He.—Any faults, of course.

She.—I fear that you are not a good critic.

He.—I may not be; but you certainly have none of the bad habits that we have enumerated.

She.—Oh! you couldn't see them if I had.

He.—From sheer stupidity?

She.—Hardly; only as far as I am concerned, you have become accustomed to think of me as did Dick of Maisie, in "The Light that Failed" that "The Queen can do no wrong."

He.—That reminds me—I have just finished reading "The Light that Failed," and I am sure that I shall never get away from the awfulness of it—the awfulness of having the light go out forever.

She.—Kipling makes one see it all so vividly, where he says:

"'I shan't.' The voice rose in a wail, 'My God! I'm blind, and the darkness will never go away.' He made as if to leap from the bed, but Torpenhow's arms were around him, and Torpenhow's chin was on his shoulder, and his breath was squeezed out of him. He could only gasp, 'Blind!'"

He.—And again, the picture that Kipling draws of the blind man who suddenly finds himself unable to do that which he has been accustomed to do. I have the book with me:

"A wise man (who is blind) will keep his eyes on the floor and sit still. For amusement he may pick coal, lump by lump, out of a light scuttle, with the tongs, and pile it in a little heap by the fender, keeping count of the lumps, which must all be put back again, one by one, and very carefully. He may set himself sums if he cares to work them out; he may talk to himself, or to the cat if she chooses to visit him; and if his trade has been that of an artist he may sketch in the air with his forefinger: but that is too much like drawing a pig with his eyes shut. He may go to his bookshelves and count his books, ranging them in order of their size; or to his wardrobe and count out his shirts, laying them in piles of two or three on the bed, as they suffer from frayed cuffs or lost buttons. Even this entertainment wearies after a time; and all the times are very, very long."

I suppose that this portrayal is true to life.

She.—Undoubtedly, in a way; but I had a novel experience when traveling East this summer. While on the train, I saw a gentleman, who was trying to interest a little boy, who did not respond to his advances. I heard him ask the child whether he was a little boy, and how old he was. I saw then that the gentleman was blind, and thinking that he might prefer to talk with me, I introduced myself to him and found him a most delightful conversationalist. He told me that he had become blind very suddenly five years ago, but that his work had not been interrupted for a day since. His position as manager of a large corporation necessitated his frequent journeying in railroad trains, but he had continued to travel as before, sometimes with his secretary, and sometimes alone. He was alone when I met him. He was certainly delightfully cheerful and entertaining; and withal, he was fully informed on current topics of interest. It seemed almost impossible to realize that he was blind.

He.—His case is extraordinary; but, of course, he was not an artist, as was poor Dick, before the "light went out."

I have just discovered another reason why you are so very interesting. It is because you always have some novel experience to recount.

She.—Yes; but you know, we decided that people did not care, as a rule, to hear others talk.

He.—Well, I shall retract my decision. I have concluded that we usually like to hear others talk, if they have something interesting to tell.

She.—Yes; we are all children, in a sense. Tell us a story, and we will listen, provided the story-teller knows how to tell it.

He.—Do you know what I have been thinking of while you were telling me this incident?

She.—That we had gotten a long way from our original subject?

He.—No; I was thinking of how much you had said in comparatively few words, and that in telling this incident, you had certainly conformed to Golden Rule Number I.: AVOID UNNECESSARY DETAILS.

She.—And you have conformed to both the rules that we have learned.

He.—Thank you. Let me see, Golden Rule Number I. is: "AVOID UNNECESSARY DETAILS." Rule Number II.: "NOT TO ASK QUESTION NUMBER TWO UNTIL QUESTION NUMBER ONE HAS BEEN ANSWERED, nor be too curious nor too disinterested;" that is, "do not ask too few nor too many questions; just enough."

She.—And our new rule, Golden Rule Number III.: D<sup>O</sup> NOT INTERRUPT ANOTHER WHILE HE IS SPEAKING.

He.—How frequently this rule is broken! Many persons, who ordinarily are well bred, have the very bad habit of interrupting others. But I deserve no credit for observing Golden Rule Number III., for you are never tiresome; you never tell a long story.

She.—No; I don't do that. I knew a gentleman once who used to say with a groan, to his niece, who was rather verbose, "O Alma! You tell such a long story. Make it short;" and so I always try to *make my story short*.

# **GOLDEN RULE NUMBER IV**

*Do not contradict another, especially when the subject under discussion is of trivial importance.*

He.—We always seem to drift back to our favorite topic, "How not to bore." At least, we discuss it so frequently, that I assume we are mutually interested.

She.—I assure you that I am very much interested in everything that assists me in making myself more pleasing to my friends.

He.—If you would not regard my compliments so dubiously, I should say that that would be impossible.

She.—Another case of the infallibility of the queen? But to go back to our subject, I often wonder whether this pleasure that we take in receiving the approval of others, is not virtually the root of all good. It is certainly most fortunate that we do care for the good opinion of our fellow-beings, and especially where we strive to merit it.

Somehow, we never seem to outgrow our childish love for rewards. I suppose that if the truth were told, much that we think we do for the sake of culture, is really done for the sake of Dame Grundy. Of course, I do not mean as applied to vain self-glorification, but rather to our higher aims and purposes. Most of us, for example, think that we make great efforts along the lines of selfimprovement for the soul-satisfaction that our efforts may give us; but I wonder how steadfastly one would work—each at his chosen calling—if one were on a desert island, remote from "all the haunts of men." But to return to our subject, you say that your latest discovery is that even grown persons contradict one another. I thought that only children had this fault.

He.—So did I; but my attention was called to this a few days since when visiting my sister. While she was telling me something of great interest to us both, her little daughter contradicted her several times in the course of our conversation. Partly because I was annoyed, and partly because I wished to teach the child a lesson, I said to my sister, "Have you ever noticed how

frequently children contradict their elders? It is certainly one of the greatest faults that a child can have." "Yes," she answered, "but many grown persons have the same fault." And when I expressed surprise, she added, "If you are inclined to doubt the truth of this assertion, just try to tell something in the hearing of others who are familiar with the story, and you will soon discern that the fault is not confined to children." And then I discovered this fault not only in others, but also in myself.

She.—Oh, dear! maybe I, too, am guilty of the same offence.

He.—I am sure that you never contradict any one in the way that I mean. It is certainly very embarrassing to make a statement, and then to have it contradicted, even though the matter is of little consequence.

She.—How many rules have we learned so far?

He.—Golden Rule Number I. is: "AVOID UNNECESSARY DETAILS." Rule Number II.: "D<sup>O</sup> NOT ASK QUESTION NUMBER TWO UNTIL NUMBER ONE HAS BEEN ANSWERED"; DO NOT BE TOO CURIOUS NOR TOO DISINTERESTED; that is, do not ask too many questions nor too few; just enough. Rule Number III.: D<sup>O</sup> NOT INTERRUPT ANOTHER WHILE HE IS SPEAKING.

She.—And our new rule, Golden Rule Number IV.: D<sup>O</sup> NOT CONTRADICT ANOTHER, ESPECIALLY WHEN THE SUBJECT UNDER DISCUSSION IS ONE OF TRIVIAL IMPORTANCE.

He.—So, if Mrs. Van Stretcher tells us that Mrs. De Waters has crossed the ocean a dozen times in as many years, we are not to say, "Pardon us, only six, as she goes abroad only once in two years, which makes just—Oh, yes! just twelve times."

She.—Yes, the person who contradicts, frequently restates the matter merely in another way.

# **GOLDEN RULE NUMBER V**

*Do not do all the talking; give your tired listener a chance.*

He.—You haven't asked me about my golden discovery.

She.—Oh, dear! is there still another rule to learn? You know, we have already had four.

He.—No; this isn't a rule. I have about come to the conclusion that people are charming in proportion as they can rise above the commonplace. Of course they must observe all our golden rules, but this observance alone will not make them interesting in conversation. Last night, for example, I never was so greatly bored as when talking with a young lady to whom I had been recently introduced. She was so well bred that she observed all the golden rules from A to Z, and yet she was tiresome beyond endurance, simply *because she hadn't a soul*. She was a Philistine of the deepest dye. I must say that I am so conventional, in a way, that I eschew Bohemianism, but an outand-out Philistine,—give me a Bohemian every time.

She.—Then, I suppose that Golden Rule Number V. would be: "ACQUIRE <sup>A</sup> SOUL,—AND ASSUME ONE IF YOU HAVE IT NOT."

He.—I suppose it is innate—one's soul, which to me stands for one's love of the beautiful—for the ideal. You see, whatever you speak about, you lift out of the commonplace. Life seems quite "worth the while," when I am with you. All the inspiring things—books, music, painting—take on a new meaning when we talk about them. Last evening my newly-made acquaintance and I discussed these subjects, but they did not interest me. Julia Marlowe, whom she had just seen, was merely a pretty woman who dressed perfectly; the latest book was something that bored, but that had to be read because everybody else was reading it. Music was an unknown quantity. What shall we do with Philistines like this?

She.—Leave them to their idols. They will not be alone, for there are many to keep them company. The trouble with many persons is that they do not

cultivate an admiration for the beautiful—beautiful pictures, exquisite music, delightful books. They live in a world of materialism. Handsome houses, exquisite paintings, well-filled libraries are to them mere possessions valuable because they are the embodied insignia of wealth. The person of high ideals delights in the beautiful, because it brings him into harmony with that perfection for which he strives. In a beautiful painting, he sees the reaching out of the artist to produce not what is, but what should be; in a great literary production, the master intellect that can mold words as wax in the hands of an artisan; in beautiful music, the soul of the composer who can make one feel all that he has felt when under the magic sway of harmony; and, so, beautiful things are loved, not alone for themselves, but for what they represent; for nothing beautiful has ever existed without its master creator the power behind the throne—where the monarch beauty is at the beck and call of that giant—intellect.

He.—Then, if we are to belong to the class who love the beautiful or what it represents, we are to cultivate our souls—that part of us which brings us *en rapport* with the divine in the universe. We are not to be sordid; we must not wish simply to possess—we must cultivate a love for the ideal—for what the beautiful represents.

She.—Yes; and this can be done. In our modern schools, the best in literature, in art, in music, is brought to the children. The child of to-day learns of Mozart, of Handel, of Wagner, and hears their music. He sees representations of great masterpieces of art, and learns to love the beautiful Madonnas of Raphael—to know the paintings of Rosa Bonheur—of Jean Francois Millet. This education can not fail to instill in children a love for the beautiful. To them the world takes on a roseate tinge, while their minds eventually become store-houses in which are garnered the treasured thoughts of the ages. Nothing in every-day life can be wholly commonplace; each peculiar incident in life, each peculiar mood of nature brings its accompanying suggestion.

He.—Do you know, you are saying what I should like to say, but what I cannot find words to express. Possibly, that is one reason why I enjoy your society more than that of all others—because you say the things that I would say, if I could but express my thoughts. It is for this reason that we admire an author, because he puts into words what we think; what we feel.

She.—I think we should add Golden Rule Number V. to our list, namely, D<sup>O</sup> NOT DO ALL THE TALKING; GIVE YOUR TIRED LISTENER AN OPPORTUNITY TO SPEAK.

He.—I am sure that I would rather listen than talk when you are with me.

She.—I am half inclined to believe you, for you are certainly perfect—as a listener.

# **GOLDEN RULE NUMBER VI**

*Be not continually the hero of your own story; and, on the other hand, do not leave your story without a hero.*

He.—

"Ships that pass in the night, and speak each other in passing, Only a signal shown and a distant voice in the darkness; So on the ocean of life, we pass and speak one another, Only a look and a voice, then darkness again and a silence."

She.—And what recalled the poem?

He.—I was thinking of the people whom we meet, and who "speak us in the passing." People whom we may never meet again, but whom we never can forget.

She.—That intangible something which makes us wish to become more closely associated with our newly-made acquaintance,—what is it? It is indefinable. We meet some one at the theater, at the club, at the social function, and there lingers with us for many days, the remembrance of the few brief moments in which we felt that we were as "twin spirits moving musically to a lute's well ordered law." Strange as it may seem, we live in a world of people,—people to the right of us, people to the left of us, everywhere about us, and only here and there a kindred spirit in whose moral and mental atmosphere we bask as in the rays of sunshine. This something that makes us feel that only the element of time is needed to make of our newly-formed acquaintance a friend that shall last through life,—what is it? A warm hand clasp, a friendly word, and in one brief moment that mysterious something that clouds the soul, is thrown aside, and in our sky a new star appears as fixed as Polaris in the heavens.

When we have an experience of this kind, although we may have interchanged but few words with our new friend, we feel intuitively that we

could spend many hours together and that we should never tire of exchanging ideas.

He.—Yes; but does this not presuppose a mind stored with those "treasured thoughts" about which we were speaking in our last conversation?

She.—Possibly, in a sense; but first of all, it presupposes harmony of taste, of feeling, of ideas. This does not mean, of course, that each shall agree with the other in all essentials, but that each shall have the same broad and intelligent way of looking at a subject, and a consideration each for the other's opinions.

He.—I think, though, that as a basis for harmonious intercourse, there must be an elimination of self. No one who is thoroughly selfish can interest any one but himself. It seems to me that the ideal relation between friends presupposes an entire elimination of self.

She.—Not necessarily so. One of the most tiresome persons that I know, is a gentleman who never refers to himself, to his aspirations, or to his plans; and for this reason, he fails entirely to awaken in his listener any interest in his personality whatsoever. He is the antipode of the person who talks only of what interests him. The person who uses discretion will not avoid all reference to himself, nor will he continually make himself the hero of his own story. It behooves us all to examine ourselves, and if we have either one of these faults to rid ourselves of it at once. In directing the trend of conversation, the tactful person will choose topics of mutual interest. People are interesting not in proportion as they recount their personal experiences, but as they evince a broad, general interest in what concerns others.

He.—We might add another golden rule to our list,—Golden Rule Number VI: B<sup>E</sup> NOT CONTINUALLY THE HERO OF YOUR OWN STORY, NOR ON THE OTHER HAND, DO NOT LEAVE YOUR STORY WITHOUT <sup>A</sup> HERO. In other words, it is fatal to one's success as a conversationalist either to eliminate oneself entirely or to appear self-centered.

She.—You might say to *be* self-centered. Selfishness is one of the most disagreeable traits that a person can have, and he who has this to a marked degree should try to eradicate it. Some one has said, "If we had to count our ills, we would not choose suspense," we might add, "If we had to choose our faults we *should* not choose selfishness." A person may observe all the

golden rules that we have enumerated, but if he is at heart a selfish person, his conversation will lack the charm that emanates from the whole-souled individual whose first thought is to interest and entertain others. Let us cultivate an unselfish spirit, for without this, our words will be but as "sounding brass and tinkling cymbals."

# **GOLDEN RULE NUMBER VII**

*Choose subject of mutual interest.*

He.—And here we are again at one of your charming "at homes," and I, as usual, am the only guest.

It is delightful of you to select for my visits those evenings where there is no possibility of our being interrupted while discussing our favorite topic.

She.—If I were "not at home" on these occasions, we should have very little opportunity to talk about the subjects in which we are mutually interested. It is decidedly paradoxical, is it not, to be at home under the circumstances?

He.—It is, to say the least, decidedly pleasant; for, otherwise, how should you be able to teach me that delightful art—the Art of Conversation? I am just selfish enough to exult in my being the only diplomat at your "salons."

She.—What is that line about conversation's being like an orchestra where all the instruments should bear a part, but where none should play together?

He.—To my thinking, conversation is most delightful when it is most unlike an orchestra. For my part, I prefer those charming *duos* where the sweet voice of the soprano rises "far above the organ's swell."

She.—Conversation is more often like an orchestra where all the instruments play together, and where no particular one can be heard. I see that a conversation in which many take part is not to your liking.

He.—As in music, so with my friends, I prefer to follow the individual; to come into harmony with his thoughts and feelings. The trite saying that corporations have no souls can be applied with equal propriety to a body of individuals at a social function, where the bored look on their faces shows that they have failed to find a subject of general interest, and are in consequence suffering in durance vile.

She.—Conversation is enjoyable only when the participants are equally

interested in the subject under discussion; and while it is not difficult for two persons to find topics of mutual interest, it is not so easy for several individuals to "hit upon" some topic in which all are equally interested; consequently, there is much greater opportunity for enjoyment in social converse where only two are "gathered together."

He.—Yes, I know; no matter how apparently dry a subject is to me, it might be of keen interest to some one else.

She.—Certainly. Only a few evenings since, I noticed, at a social function, a lady and gentleman deeply engaged for a long time, in the discussion of some topic in which each was apparently vitally interested. I learned afterwards that the gentleman was the editor-in-chief of a new dictionary recently compiled, and that the lady was the teacher of English in a college. They were discussing the relative merits of the diacritical markings of the Century, Standard, and International dictionaries compared with those of "old Webster."

He.—I should call that an extremely dry subject.

She.—Oh! they found it fascinating. They really became excited—not impolitely so—but deeply absorbed in following each other through the maze of half circles and dots, straight lines and curved.

He.—That is why people whom we meet—polite and kindly people—try "to draw us out," to find what we are interested in, so as not to hinge the conversation on politics when it should be on potatoes or on poetry.

She.—The whole secret of pleasant social converse lies in the participants' finding subjects of mutual interest. Why, I have heard two persons discuss by the hour the feasibility of raising ducks as a means of livelihood; others, that of manufacturing a washing-machine that would wash and boil clothing at the same time. So you see, it doesn't matter whether the topic is politics or poetry; the latest work in science or in fiction; whether it is music or painting; the main point is that the subject shall be of mutual interest to those discussing it.

He.—Then we may add another rule to our list—Golden Rule Number VII.: CHOOSE SUBJECTS OF MUTUAL INTEREST. Don't discuss politics when you should be talking about poetry; fact, instead of fiction; science, instead of sunsets.

She.—Yes; and be sure that both are equally interested or else one or the other will have that bored look to which you referred a short time since.

He.—People sometimes appear interested when they are not.

She.—Yes; but the keen observer will detect whether the smile extends farther than the parted lips. If people would be genuine, and less artificial, after a pleasant evening spent in social converse, there would linger with one a memory as pleasing and as refreshing as is the sweet fragrance wafted from country clover fields to the traveler on the dusty road. In our social intercourse with one another let us omit all unpleasant topics, and choose only those in which both are equally interested.

# **GOLDEN RULE NUMBER VIII**

*Be a good listener.*

He.—And here we are again in your bower—your bower of roses and carnations. It is always summer here, for there are always flowers. You wear them, too, as another would wear her jewels.

![](_page_29_Picture_0.jpeg)

"She went by dale, and she went by down, With a single rose in her hair."

She.—This is as I like my flowers—around me and about me. Conservatories have no charm for me, for one cannot live in a conservatory. I like my roses, where, as I sit and write, I can inhale their fragrance, and see their wondrous beauty. What is more beautiful than a rose?

He.—Wouldn't "The Woman with the Rose" make a nice title for a poem?

She.—You are really lacking in originality. You never would have thought of it in the world if "The Man with the Hoe" had not suggested it.

He.—Oh! I agree with you that I am not original, and that the title was suggested; but not, as you think, by "The Man with the Hoe."

She.—Aren't we wasting valuable time? You know we were going to discuss Golden Rule Number VIII., and we haven't even decided what it shall be.

He.—Be a good listener! Wasn't it Addison who said that the most skillful flattery was to let a person talk on, and be a good listener? But somehow, this has such a ring of insincerity. Now, I am sure that I should not wish to be beguiled into thinking that I was entertaining my friend when, in reality, I was boring him.

She.—Yes; but a person who observes all our golden rules will not "talk on." You know, there are few persons who can "talk on," and not bore their listeners. Of course, if people were tactful and would observe Golden Rule Number VII.—CHOOSE TOPICS IN WHICH ALL ARE INTERESTED—it would not be necessary for the listener to "feign an interest if he has it not."

He.—But what are we going to do when we are in the society of those who do not observe this rule?

She.—Sometimes, we can enjoy the conversation of others for reasons opposite to what might be expected. For example, a few days since, I was one of several guests at a luncheon, and I was very much amused in noting how subjects, which in themselves seemed very prosaic, could elicit so much enthusiasm in their discussion. For example, the guests discussed the making of salads, and much enthusiasm was expended over a mixture of fruit, nuts, and olive oil. The subject was certainly highly relevant, as the very kind of salad in question was in evidence, calling forth enthusiastic encomiums from all.

He.—I suppose you are often amused at the amount of interest shown in trivial subjects.

She.—No; I, too, at times, like to relax, and to talk about subjects that would

seem frivolous to many. While much of my time and close attention must necessarily be given to study, for this reason, when there is any diverting influence, I prefer, occasionally, to forget everything of a serious nature; and, like the bee that goes from flower to flower to sip of each its sweetness, so I enjoy passing from one subject to another, discussing only lightly, each in turn. So you see whether it is salads or pates; Mrs. Campbell or Paderewski; shirred gowns or pleated, these subjects at times may prove interesting and diverting.

He.—But when a person is deeply interested in some special study that *counts*, I can not see how he can find much satisfaction in the discussion of topics so very foreign to his specialty.

She.—As I have just implied, the specialist finds it necessary to relax. I have in mind a noted physician who spends many of his waking hours, and hours when he should be sleeping, either in his laboratory or with his patients; but immediately when he enters his drawing-room to greet a friend, he forgets his work utterly, for the time being, and before many minutes have passed, his listener is convulsed with laughter over some new story—the latest acquisition to the Doctor's stock.

He.—Do you know, I often wonder why people do not cultivate the art of story-telling. It seems to me that if one would entertain one's friends now and then with a good story, it would enliven what would otherwise be a very dull occasion.

She.—Story-tellers—good story-tellers—are probably born, not made; and yet, the person who is not especially gifted in this art, may succeed in entertaining his listeners, provided that he has wit enough to remember the "point," and to couch his language so that the dénouement is not surmised, for surprise is an important element in the telling of a story.

He.—Occasionally, I hear a good story, and one that I wish to remember, but I can never trust myself to repeat it for fear that I shall commit the flagrant sin of missing the "point"; and that omission would, of course, be unpardonable.

She.—I think you might become a very successful reconteur, if you would give some attention to the art in question. Of course, the important thing to remember is, what are the essentials, to omit all unnecessary details, to keep

the listener in suspense and, above all, *not to omit the point*. We can not all be Charles Lambs nor Sydney Smiths, but we can each have our little store of "funnycisms" from which to draw when the occasion is opportune, or the story relevant.

He.—Well, I suppose we must decide that one must be a good listener at all hazards, and that one must find something of interest in the conversation of others even though the subject may be "salads" when it should be "suffrage," for example. Shall we make "B<sup>E</sup> <sup>A</sup> GOOD LISTENER AT ALL HAZARDS" Golden Rule Number VIII.?

She.—Yes, I suppose so; but if we could all remember and practice our other golden rules, we should not need to add this one to the list.

He.—Let me see whether I can enumerate them.

Golden Rule Number 1.—*Avoid unnecessary details.*

- 2.—*Do not ask question number two until number one has been answered, nor be too curious nor too disinterested; that is, do not ask too many questions nor too few.*
- 3.—*Do not interrupt another while he is speaking.*
- 4.—*Do not contradict another, especially when the subject under discussion is of trivial importance.*
- 5.—*Do not do all the talking; give your tired listener a chance.*
- 6.—*Be not continually the hero of your own story; and on the other hand, do not leave your story without a hero.*
- 7.—*Choose subjects of mutual interest.*

And our latest acquisition, Golden Rule Number VIII., *Be a good listener.*

She.—You have done remarkably well to remember all these rules.

He.—Haven't I earned a reward?

She.—What shall it be?

| He.—The rose in your hair | • |
|---------------------------|---|
|                           |   |
| F                         |   |

# **GOLDEN RULE NUMBER IX**

*Make your speech in harmony with your surroundings.*

He.—Let us walk along the shore—away from our friends at the hotel. The night is far too beautiful to spend in discussing the merits of biscuit and honey compared with those of strawberries and cake.

She.—And with such a sky and such a scene before them! And the day—how perfect it has been!

> \* \* \* \* "The blue sky Leaned silently above, and all its high And azure-circled roof beneath the wave, Was imaged back and seemed the deep to pave With its transparent beauty."

He.—Oh! they're not thinking of the sea nor of the sky. Although when I saw one of the ladies gazing intently at the moon, I thought that she, like you and me, had succumbed to the influence of its magic beams; but I very soon became disillusioned, for I heard her suddenly exclaim, "Oh, I wish I had some Welsh rarebit! I am so very fond of Welsh rarebit."

She.—Her thoughts were evidently relevant, as the moon probably suggested to her, green cheese, and from that, it was only a step to the toasted article. I dislike to hear a person express a fondness for food. I know that it is correct to use "fond" in this way; but to me "fondness" should be used only with reference to one's friends; but to be fond of "Welsh rarebit"! I should prefer to use another expression.

He.—Of course you aren't fond of anything but flowers, and books, and music,—Oh! and the moon.

She.—And people; they come first.

He.—Everybody?

She.—Not everybody, only a few.

He.—Including——

She.—I think that we should go back to our friends.

He.—And discuss "Welsh rarebit"? Let us take this boat and glide over the "silvery lake." We can find more interesting subjects to talk about than edibles; and, if we cannot, we can at least be silent and let the glorious night speak for us.

She.—Because of just such nights, I come here every year.

He.—But the moon, like the sun, shines everywhere for all.

She.—Yes, but not everywhere alike. There must be trees with branches outspread to catch its silvery beams, and giant hills in the distance to form a heavy background. The full moon shining on our great Lake Michigan is a glorious sight, but that which is needed to make the scene perfect is not there. But here—nothing is wanting.

> O beauteous Lake! How radiantly dost thou wear thy jewels Upon thy bosom fair,—made fairer still By Luna's silvery beams.

![](_page_36_Picture_0.jpeg)

How radiantly dost thou wear thy jewels Upon thy bosom fair,—made fairer still By Luna's silvery beams.

He.—The poet is nature's interpreter. He expresses what we feel; what we

should wish to say, were we able to express our thoughts in poetic language. But sometimes he does not interpret truly. Wasn't it Browning who said:

> "Never the time and the place And the loved one altogether"?

She.—I don't see the relevancy of the quotation. We must go back to the hotel. Our friends will miss us.

He.—But you haven't heard my lesson yet, as we used to say in school. I have to recite all the golden rules, and add our new one. What shall it be?

She.—Rule Number IX.: ONE'<sup>S</sup> SPEECH SHOULD BE IN HARMONY WITH ONE'<sup>S</sup> SURROUNDINGS.

He.—In other words, a person should not talk about cheese when the moon would be a more fitting topic.

She.—Or, when it might be more fitting to remain silent.

He.—Some one has said, "Silence is the virtue of the feeble," but it is probably as often the virtue of the wise.

She.—It was Carlyle who said: "Consider the significance of SILENCE: it is boundless, never by meditating to be exhausted, unspeakably profitable to thee: Cease that chaotic hubbub, wherein thy own soul runs to waste, to confused suicidal dislocation and stupor; out of Silence comes thy strength. 'Speech is silvern, Silence is golden; Speech is human, Silence is divine.'"

# **GOLDEN RULE NUMBER X**

#### *Do not exaggerate.*

He.—You may remember that one of the extracts that I read to you from my note-book referred to exaggeration in conversation. Do you know, I have been paying attention to this fault, and I find that it is decidedly general even with people who are supposed to be honest and sincere. It is really one phase of falsifying; in my opinion, it is a very disagreeable habit, and one that a person should try to rid himself of.

She.—Parents can not be too careful in the bringing up of their children to see that they do not form the habit of exaggerating what they undertake to tell. Why! Some persons can not make the simplest statement without exaggerating the facts. For instance, if one undertakes to give the price of a garment or of some furniture, the amount paid is always increased in the telling of the story; and so with the narration of trivial events—the speaker will enlarge his statements until he presents a distorted picture to the mental vision of the listener.

The exaggeration of facts should certainly be avoided; and a person can overcome this tendency in himself, if, when he finds that he is making a misstatement, he will correct himself, and give a true version. For example, if he finds that he is fixing the cost of a possession at five dollars, when it should be four dollars and fifty cents, he can correct the error without even betraying his intention to falsify. By doing this, he gradually trains himself to adhere to facts; for, while the price of the article may be a matter of small consequence, it is a matter of far more importance that the person who has the habit shall correct his tendency to misstate facts. So again, when one is narrating an incident in one's experience, the same strict adherence to the facts should be observed. In this way a person establishes a reputation for veracity. We all have friends in whose statements we place no reliance, simply because we know that they invariably exaggerate every fact that comes within their observation or experience. I know of no fault in conversation that is more grievous than this nor that can give one such a

general air of insincerity in all things.

He.—I know, I have friends whom I can not believe—no matter how serious they are in impressing upon me, the truth of the information that they are so willing to impart.

She.—Of course, when persons of this kind attack the reputation of others then, indeed, does their fault become a serious one; but there are many, otherwise well-meaning, persons who would not speak ill of another, who place themselves continually at a disadvantage by their exaggerated speech. There is the school-girl, for example, who finds every person and thing *perfectly lovely*—or *perfectly horrid*, as the case may be; who had the *most beautiful* time in her life last night; who finds her teacher *divine*; tennis, a *dream of delight*—everything, no matter what, is *just dandy*—or *dear*. Later in life, she may exaggerate as to her husband's income; her children's virtues or appearance; the price of her garments—and in this way she will acquire the unenviable reputation for insincerity, unreliability. No one will give any credence to what she says, simply because she is known always to exaggerate the facts.

He.—I feel as you do, and when I find myself enlarging upon the facts, I try immediately to correct my fault and adhere to an actual recital.

She.—Of course, we know that in telling a story for the sake of its humor, a person will sometimes lapse into an enlargement of the details, but, as Rudyard Kipling would say, "That is another story."

He.—Had we not better make this Golden Rule Number X.?

I wonder whether I can recite all the Golden Rules:

Golden Rule Number 1.—*Avoid unnecessary details.*

- 2.—*Do not ask question number two until number one has been answered, nor be too curious nor too disinterested; that is, do not ask too many questions nor too few.*
- 3.—*Do not interrupt another while he is speaking.*
- 4.—*Do not contradict another, especially when the subject under*

*discussion is of trivial importance.*

- 5.—*Do not do all the talking; give your tired listener a chance.*
- 6.—*Be not continually the hero of your own story; and, on the other hand, do not leave your story without a hero.*
- 7.—*Choose subjects of mutual interest.*
- 8.—*Be a good listener.*
- 9.—*Make your speech in harmony with your surroundings.*
- 10.—*Do not exaggerate*—our new rule.

# **GOLDEN RULE NUMBER XI**

*Indulge occasionally in a relevant quotation, but do not garble it.*

He.—I have just been reading a very interesting article entitled "Learning by Heart," and I have become impressed with the idea that one should occasionally commit to memory inspiring passages in verse and prose. In the language of the author: "They may come to us in our dull moments, to refresh us as with spring flowers; in our selfish musings, to win us by pure delight from the tyranny of foolish castle-building, self-congratulations, and mean anxieties. They may be with us in the workshop, in the crowded streets, by the fireside; sometimes on pleasant hill-sides, or by sounding shores; noble friends and companions—our own! never intrusive, ever at hand, coming at our call."

She.—Some one has said that an apt quotation is as good as an original remark. It is certainly always relevant. We cannot all be Wordsworths or Tennysons; Charles Lambs or Carlyles, but we can make some of their best thoughts our own. A conversation or a letter in which some choice quotation finds a place, is certainly thus improved and lifted above the commonplace. It was Johnson who said that classical quotation was the parole of literary men all over the world.

He.—For a long time, I have been copying in a note-book, extracts that have interested me, but it did not occur to me to commit them to memory. Hereafter, I shall do so, for I am sure that it will add to my resources both in conversation and in letter-writing.

She.—Some of the most delightful letters that I have ever received have been those in which there have been quotations, so relevant, so charming that, for the time being, they seemed to have been written for me alone.

He.—I have always hesitated to interpolate my conversation or letters with quotations, for fear that I might seem to be airing my familiarity with classical literature.

She.—Of course, one does not wish to appear pedantic; and one will not, if one will use the quotation for the occasion, instead of making an occasion for the quotation. The proportions, too, of a conversation or a letter must be preserved. If one is talking about a commonplace subject, the quotation, if one is made, should be in keeping with the thought. As a clever writer has said, "A dull face invites a dull fate," and so with a commonplace subject; the treatment should be in accordance with it.

He.—Some persons are never able to quote a passage or tell an anecdote without perverting the meaning. In fact, I have long been interested in noticing how inexact the majority of people are in making statements of all kinds. I can recall several friends who are unreliable in what they say. Their statements should be "checked up"—verified, as we say in business.

She.—As some one has said: "A garbled quotation may be the most effectual perversion of an author's meaning; and a partial representation of an incident in a man's life may be the most malignant of all calumnies."

He.—How very relevant that quotation is. You have certainly just exemplified your own suggestion, namely, that the quotation should be used to suit the occasion.

Shall we make this Golden Rule Number XI.: OCCASIONALLY INDULGE IN <sup>A</sup> RELEVANT QUOTATION, BUT DO NOT GARBLE IT?

She.—Certainly; a Golden Rule that it is well occasionally to observe.

# **GOLDEN RULE NUMBER XII**

#### *Cultivate tact.*

He.—"Consider the significance of SILENCE: it is boundless, never by meditating to be exhausted, unspeakably profitable to thee. Cease that chaotic hubbub, wherein thy own soul runs to waste to confused suicidal dislocation and stupor; out of SILENCE comes thy strength. Speech is silvern, silence is golden; speech is human, silence is divine."

She.—And what suggested the lines from Carlyle?

He.—Oh! I was thinking of one of the extracts in my list of quotations relevant to our subject, "The Art of Conversation." "It is when you come close to a man in conversation that you discover what his real abilities are." One might add, *and what they are not*.

She.—And I suppose that the line suggested the thought that, in many instances, to quote Carlyle again, "Speech is silvern, silence is golden; speech is human, silence is divine."

He.—Undoubtedly, in many instances, it would be better to preserve a discreet silence than to say that which is disagreeable or untruthful. Of course the tactful person can frequently so turn the conversation as to be obliged to adopt neither alternative.

She.—One should always be truthful, and one should never say that which would be displeasing to the listener,—of course, we must except those semidisagreeable things which we sometimes feel privileged to say to our relatives or our best friends, on the ground that we are champions on the side of truth.

He.—I have always maintained that it is only a true friend who will tell the unpleasant *home* truths.

She.—Yes; we can all remember occasions when our expressed resentment at some well-meant criticism offered by a member of the family, for example,

was met by the rejoinder that *it was the truth*.

He.—The "truth" is not always pleasing to the ear, and I agree with you that, except in the case of the privileged few, only the pleasing things should be told.

She.—That is all—provided, of course, that they are at the same time truthful.

He.—And if they are not?

She.—Then they should be left unsaid, for one's speech should never be insincere or flippant.

He.—To be told that one is not looking well, or is looking ill, or older, as the case may be, is certainly not conducive to pleasant feelings on the part of the listener.

She.—Frequently, the person who would not be guilty of offenses of this kind, will arrive at the same results in an indirect way. For example, A, who may be too polite to tell B that he is getting "along in years," will ask him whether the handsome young lady seen in his company at the theater the previous evening *is his daughter*, thinking thus to compliment him as being the proud parent of so beautiful a maiden; whereas, A, who prides himself upon his youthful appearance, and thinks that he is "holding his own" against Father Time, fails to appreciate the "would-be" compliment. Mrs. C informs Mrs. D that she looks ten years younger since becoming *so stout*, while Mrs. E. advises Mrs. F. to buy a hat, as up-to-date *elderly* women no longer wear bonnets; and so on through the alphabet.

He.—Oh! I suppose it is impossible for people who are so obtuse as these to go through the world without blundering at every step.

She.—I don't know. It seems to me that these unthinking people might be taught to think. Surely, we can all learn by observation and experience; and it would seem that persons fairly introspective might discover that it is not direct speech alone that wounds or offends. We all know that the prettiest compliments are often those which are implied; and, conversely, sometimes it is the suggestive criticism or censure that wounds the most.

He.—Then we must remember that we should keep our minds alert; that we must not be found napping; that it is not sufficient that we refrain from giving pointed home thrusts, but that we should never, even by indirect speech, leave with our listener an unpleasant memory.

She.—Yes; we meet some people,—often only for a moment,—only once, perhaps, in a lifetime; but it is possible, in many instances, to make that moment linger forever as a pleasant memory to that other. We can all remember some occasion when there was merely a handclasp, when but few words were spoken, but the memory is ours forever. Something that was said, perhaps, seemingly trivial, but glorified by the speaker's smile, by the sincerity of his heart.

He.—After all, to sum it up, it is the word T-A-C-T, or the lack of it, that makes a person correspondingly agreeable or disagreeable in his social intercourse with another. Someone has defined tact as the art of pleasing, and so I should think we might add this mandate to our golden rules—*Cultivate the art of pleasing,—say the right thing or say nothing.*

Now, I am going to recite all our golden rules, for I know them by heart:

Golden Rule Number 1.—*Avoid unnecessary details.*

- 2.—*Do not ask question number two until number one has been answered; nor be too curious and, too disinterested; that is do not ask too many questions nor too few.*
- 3.—*Do not interrupt another while he is speaking.*
- 4.—*Do not contradict another, especially when the subject under discussion is of trivial importance.*
- 5.—*Do not do all the talking; give your tired listener a chance.*
- 6.—*Be not continually the hero of your own story; nor, on the other hand, do not leave your story without a hero.*
- 7.—*Choose subjects of mutual interest.*
- 8.—*Be a good listener.*

- 9.—*Make your speech in harmony with your surroundings.*
- 10.—*Do not exaggerate.*
- 11.—*Indulge occasionally in a relevant quotation, but do not garble it.*
- 12.—*Cultivate tact—our new rule.*

![](_page_46_Picture_4.jpeg)

#### \*\*\* END OF THE PROJECT GUTENBERG EBOOK THE ART OF CONVERSATION: TWELVE GOLDEN RULES \*\*\*

Updated editions will replace the previous one—the old editions will be renamed.

Creating the works from print editions not protected by U.S. copyright law means that no one owns a United States copyright in these works, so the Foundation (and you!) can copy and distribute it in the United States without permission and without paying copyright royalties. Special rules, set forth in the General Terms of Use part of this license, apply to copying and distributing Project Gutenberg™ electronic works to protect the PROJECT GUTENBERG™ concept and trademark. Project Gutenberg is a registered trademark, and may not be used if you charge for an eBook, except by following the terms of the trademark license, including paying royalties for use of the Project Gutenberg trademark. If you do not charge anything for copies of this eBook, complying with the trademark license is very easy. You may use this eBook for nearly any purpose such as creation of derivative works, reports, performances and research. Project Gutenberg eBooks may be modified and printed and given away—you may do practically ANYTHING in the United States with eBooks not protected by U.S. copyright law. Redistribution is subject to the trademark license, especially commercial redistribution.

START: FULL LICENSE

#### THE FULL PROJECT GUTENBERG LICENSE

PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK

To protect the Project Gutenberg™ mission of promoting the free distribution of electronic works, by using or distributing this work (or any other work associated in any way with the phrase "Project Gutenberg"), you agree to comply with all the terms of the Full Project Gutenberg™ License available with this file or online at www.gutenberg.org/license.

#### **Section 1. General Terms of Use and Redistributing Project Gutenberg™ electronic works**

- 1.A. By reading or using any part of this Project Gutenberg™ electronic work, you indicate that you have read, understand, agree to and accept all the terms of this license and intellectual property (trademark/copyright) agreement. If you do not agree to abide by all the terms of this agreement, you must cease using and return or destroy all copies of Project Gutenberg™ electronic works in your possession. If you paid a fee for obtaining a copy of or access to a Project Gutenberg™ electronic work and you do not agree to be bound by the terms of this agreement, you may obtain a refund from the person or entity to whom you paid the fee as set forth in paragraph 1.E.8.
- 1.B. "Project Gutenberg" is a registered trademark. It may only be used on or associated in any way with an electronic work by people who agree to be bound by the terms of this agreement. There are a few things that you can do with most Project Gutenberg™ electronic works even without complying with the full terms of this agreement. See paragraph 1.C below. There are a lot of things you can do with Project Gutenberg™ electronic works if you follow the terms of this agreement and help preserve free future access to Project Gutenberg™ electronic works. See paragraph 1.E below.
- 1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation" or PGLAF), owns a compilation copyright in the collection

of Project Gutenberg™ electronic works. Nearly all the individual works in the collection are in the public domain in the United States. If an individual work is unprotected by copyright law in the United States and you are located in the United States, we do not claim a right to prevent you from copying, distributing, performing, displaying or creating derivative works based on the work as long as all references to Project Gutenberg are removed. Of course, we hope that you will support the Project Gutenberg™ mission of promoting free access to electronic works by freely sharing Project Gutenberg™ works in compliance with the terms of this agreement for keeping the Project Gutenberg™ name associated with the work. You can easily comply with the terms of this agreement by keeping this work in the same format with its attached full Project Gutenberg™ License when you share it without charge with others.

- 1.D. The copyright laws of the place where you are located also govern what you can do with this work. Copyright laws in most countries are in a constant state of change. If you are outside the United States, check the laws of your country in addition to the terms of this agreement before downloading, copying, displaying, performing, distributing or creating derivative works based on this work or any other Project Gutenberg™ work. The Foundation makes no representations concerning the copyright status of any work in any country other than the United States.
- 1.E. Unless you have removed all references to Project Gutenberg:
- 1.E.1. The following sentence, with active links to, or other immediate access to, the full Project Gutenberg™ License must appear prominently whenever any copy of a Project Gutenberg™ work (any work on which the phrase "Project Gutenberg" appears, or with which the phrase "Project Gutenberg" is associated) is accessed, displayed, performed, viewed, copied or distributed:

This eBook is for the use of anyone anywhere in the United States and most other parts of the world at no cost and with almost no restrictions whatsoever. You may copy it, give it away or re-use it under the terms of the Project Gutenberg License included with this eBook or online at [www.gutenberg.org.](https://www.gutenberg.org) If you are not located in

the United States, you will have to check the laws of the country where you are located before using this eBook.

- 1.E.2. If an individual Project Gutenberg™ electronic work is derived from texts not protected by U.S. copyright law (does not contain a notice indicating that it is posted with permission of the copyright holder), the work can be copied and distributed to anyone in the United States without paying any fees or charges. If you are redistributing or providing access to a work with the phrase "Project Gutenberg" associated with or appearing on the work, you must comply either with the requirements of paragraphs 1.E.1 through 1.E.7 or obtain permission for the use of the work and the Project Gutenberg™ trademark as set forth in paragraphs 1.E.8 or 1.E.9.
- 1.E.3. If an individual Project Gutenberg™ electronic work is posted with the permission of the copyright holder, your use and distribution must comply with both paragraphs 1.E.1 through 1.E.7 and any additional terms imposed by the copyright holder. Additional terms will be linked to the Project Gutenberg™ License for all works posted with the permission of the copyright holder found at the beginning of this work.
- 1.E.4. Do not unlink or detach or remove the full Project Gutenberg™ License terms from this work, or any files containing a part of this work or any other work associated with Project Gutenberg™.
- 1.E.5. Do not copy, display, perform, distribute or redistribute this electronic work, or any part of this electronic work, without prominently displaying the sentence set forth in paragraph 1.E.1 with active links or immediate access to the full terms of the Project Gutenberg™ License.
- 1.E.6. You may convert to and distribute this work in any binary, compressed, marked up, nonproprietary or proprietary form, including any word processing or hypertext form. However, if you provide access to or distribute copies of a Project Gutenberg™ work in a format other than "Plain Vanilla ASCII" or other format used in the official version posted on the official Project Gutenberg™ website (www.gutenberg.org), you must, at no additional cost, fee or expense to

the user, provide a copy, a means of exporting a copy, or a means of obtaining a copy upon request, of the work in its original "Plain Vanilla ASCII" or other form. Any alternate format must include the full Project Gutenberg™ License as specified in paragraph 1.E.1.

- 1.E.7. Do not charge a fee for access to, viewing, displaying, performing, copying or distributing any Project Gutenberg™ works unless you comply with paragraph 1.E.8 or 1.E.9.
- 1.E.8. You may charge a reasonable fee for copies of or providing access to or distributing Project Gutenberg™ electronic works provided that:
- You pay a royalty fee of 20% of the gross profits you derive from the use of Project Gutenberg™ works calculated using the method you already use to calculate your applicable taxes. The fee is owed to the owner of the Project Gutenberg™ trademark, but he has agreed to donate royalties under this paragraph to the Project Gutenberg Literary Archive Foundation. Royalty payments must be paid within 60 days following each date on which you prepare (or are legally required to prepare) your periodic tax returns. Royalty payments should be clearly marked as such and sent to the Project Gutenberg Literary Archive Foundation at the address specified in Section 4, "Information about donations to the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies you in writing (or by e-mail) within 30 days of receipt that s/he does not agree to the terms of the full Project Gutenberg™ License. You must require such a user to return or destroy all copies of the works possessed in a physical medium and discontinue all use of and all access to other copies of Project Gutenberg™ works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any money paid for a work or a replacement copy, if a defect in the electronic work is discovered and reported to you within 90 days of receipt of the work.
- You comply with all other terms of this agreement for free distribution

of Project Gutenberg™ works.

1.E.9. If you wish to charge a fee or distribute a Project Gutenberg™ electronic work or group of works on different terms than are set forth in this agreement, you must obtain permission in writing from the Project Gutenberg Literary Archive Foundation, the manager of the Project Gutenberg™ trademark. Contact the Foundation as set forth in Section 3 below.

#### 1.F.

- 1.F.1. Project Gutenberg volunteers and employees expend considerable effort to identify, do copyright research on, transcribe and proofread works not protected by U.S. copyright law in creating the Project Gutenberg™ collection. Despite these efforts, Project Gutenberg™ electronic works, and the medium on which they may be stored, may contain "Defects," such as, but not limited to, incomplete, inaccurate or corrupt data, transcription errors, a copyright or other intellectual property infringement, a defective or damaged disk or other medium, a computer virus, or computer codes that damage or cannot be read by your equipment.
- 1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES Except for the "Right of Replacement or Refund" described in paragraph 1.F.3, the Project Gutenberg Literary Archive Foundation, the owner of the Project Gutenberg™ trademark, and any other party distributing a Project Gutenberg™ electronic work under this agreement, disclaim all liability to you for damages, costs and expenses, including legal fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE PROVIDED IN PARAGRAPH 1.F.3. YOU AGREE THAT THE FOUNDATION, THE TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH DAMAGE.

- 1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND If you discover a defect in this electronic work within 90 days of receiving it, you can receive a refund of the money (if any) you paid for it by sending a written explanation to the person you received the work from. If you received the work on a physical medium, you must return the medium with your written explanation. The person or entity that provided you with the defective work may elect to provide a replacement copy in lieu of a refund. If you received the work electronically, the person or entity providing it to you may choose to give you a second opportunity to receive the work electronically in lieu of a refund. If the second copy is also defective, you may demand a refund in writing without further opportunities to fix the problem.
- 1.F.4. Except for the limited right of replacement or refund set forth in paragraph 1.F.3, this work is provided to you 'AS-IS', WITH NO OTHER WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PURPOSE.
- 1.F.5. Some states do not allow disclaimers of certain implied warranties or the exclusion or limitation of certain types of damages. If any disclaimer or limitation set forth in this agreement violates the law of the state applicable to this agreement, the agreement shall be interpreted to make the maximum disclaimer or limitation permitted by the applicable state law. The invalidity or unenforceability of any provision of this agreement shall not void the remaining provisions.
- 1.F.6. INDEMNITY You agree to indemnify and hold the Foundation, the trademark owner, any agent or employee of the Foundation, anyone providing copies of Project Gutenberg™ electronic works in accordance with this agreement, and any volunteers associated with the production, promotion and distribution of Project Gutenberg™ electronic works, harmless from all liability, costs and expenses, including legal fees, that arise directly or indirectly from any of the following which you do or cause to occur: (a) distribution of this or any Project Gutenberg™ work, (b) alteration, modification, or additions or deletions to any Project Gutenberg™ work, and (c) any Defect you cause.

#### **Section 2. Information about the Mission of Project Gutenberg™**

Project Gutenberg™ is synonymous with the free distribution of electronic works in formats readable by the widest variety of computers including obsolete, old, middle-aged and new computers. It exists because of the efforts of hundreds of volunteers and donations from people in all walks of life.

Volunteers and financial support to provide volunteers with the assistance they need are critical to reaching Project Gutenberg™'s goals and ensuring that the Project Gutenberg™ collection will remain freely available for generations to come. In 2001, the Project Gutenberg Literary Archive Foundation was created to provide a secure and permanent future for Project Gutenberg™ and future generations. To learn more about the Project Gutenberg Literary Archive Foundation and how your efforts and donations can help, see Sections 3 and 4 and the Foundation information page at www.gutenberg.org.

#### **Section 3. Information about the Project Gutenberg Literary Archive Foundation**

The Project Gutenberg Literary Archive Foundation is a non-profit 501(c)(3) educational corporation organized under the laws of the state of Mississippi and granted tax exempt status by the Internal Revenue Service. The Foundation's EIN or federal tax identification number is 64-6221541. Contributions to the Project Gutenberg Literary Archive Foundation are tax deductible to the full extent permitted by U.S. federal laws and your state's laws.

The Foundation's business office is located at 809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887. Email contact links and up to date contact information can be found at the Foundation's website and official page at www.gutenberg.org/contact

#### **Section 4. Information about Donations to the Project**

#### **Gutenberg Literary Archive Foundation**

Project Gutenberg™ depends upon and cannot survive without widespread public support and donations to carry out its mission of increasing the number of public domain and licensed works that can be freely distributed in machine-readable form accessible by the widest array of equipment including outdated equipment. Many small donations (\$1 to \$5,000) are particularly important to maintaining tax exempt status with the IRS.

The Foundation is committed to complying with the laws regulating charities and charitable donations in all 50 states of the United States. Compliance requirements are not uniform and it takes a considerable effort, much paperwork and many fees to meet and keep up with these requirements. We do not solicit donations in locations where we have not received written confirmation of compliance. To SEND DONATIONS or determine the status of compliance for any particular state visit [www.gutenberg.org/donate.](https://www.gutenberg.org/donate/)

While we cannot and do not solicit contributions from states where we have not met the solicitation requirements, we know of no prohibition against accepting unsolicited donations from donors in such states who approach us with offers to donate.

International donations are gratefully accepted, but we cannot make any statements concerning tax treatment of donations received from outside the United States. U.S. laws alone swamp our small staff.

Please check the Project Gutenberg web pages for current donation methods and addresses. Donations are accepted in a number of other ways including checks, online payments and credit card donations. To donate, please visit: www.gutenberg.org/donate.

#### **Section 5. General Information About Project Gutenberg™ electronic works**

Professor Michael S. Hart was the originator of the Project Gutenberg™

concept of a library of electronic works that could be freely shared with anyone. For forty years, he produced and distributed Project Gutenberg™ eBooks with only a loose network of volunteer support.

Project Gutenberg™ eBooks are often created from several printed editions, all of which are confirmed as not protected by copyright in the U.S. unless a copyright notice is included. Thus, we do not necessarily keep eBooks in compliance with any particular paper edition.

Most people start at our website which has the main PG search facility: [www.gutenberg.org.](https://www.gutenberg.org)

This website includes information about Project Gutenberg™, including how to make donations to the Project Gutenberg Literary Archive Foundation, how to help produce our new eBooks, and how to subscribe to our email newsletter to hear about new eBooks.